import sys
from datetime import datetime
from bacterias import Bacteria
import funciones
import random
import curses
import time

random.seed(datetime.now())

if __name__ == "__main__":
    stdscr = curses.initscr() #para poder imprimir
    curses.noecho()
    stdscr.keypad(True)
    curses.cbreak()
    #se inicializan los nodos con el archivo
    Bacteria.ciudades.nodos_archivo(sys.argv[1])
    sp = int(sys.argv[2])#cantidad de bacterias
    pc = int(sys.argv[3])#probabilidad de conjugacion
    pt = int(sys.argv[4])#probabilidad de transformacion
    pm = int(sys.argv[5])#probabilidad de mutacion
    pl = int(sys.argv[6])#probabilidad de liberacion
    pcl = int(sys.argv[7])#probabilidad de conjugacion libre
    ptl = int(sys.argv[8])#probabilidad de transformacion libre
    pml = int(sys.argv[9])#probabilidad de mutacion libre
    n = int(sys.argv[10])#cantidad de iteraciones
    size = Bacteria.ciudades.dimension -1
    bacterias = []         #arreglo de bacterias
    resistentes = []       #bacterias resistentes
    no_resistentes = []    #bacterias no resistentes
    material_genetico = [] #material genetico liberado
    mejor_peor = [0,0] #arreglo con el mejor y peor bacterias encontrados en cada iteracion
    mejor_fitness = 300000
    mejor_cv = 100
    mejor_cromosoma = []
    #se inicializan sp bacterias
    funciones.inicializacion_poblacion(bacterias,sp,size)
    var = 0
    for i in range(0,n):
        #se formula el antibiotico
        antibiotico = funciones.formular_antibiotico(bacterias)
        #se clasifican las bacterias
        funciones.clasificacion(bacterias,resistentes,no_resistentes,antibiotico)
        #se aplica conjugacion entre bacterias
        funciones.conjugacion_bacterias(resistentes,no_resistentes,pc)
        #se aplica transformacion a las bacterias no resistentes
        funciones.transformacion_bacterias(no_resistentes,material_genetico,pt)
        #se mutan las bacterias con probabilidad pm de mutar
        funciones.mutacion(bacterias,pm)
        #se vuelven a clasificar las bacterias
        funciones.clasificacion(bacterias,resistentes,no_resistentes,antibiotico)
        #se aplica el antibiotico a las bacterias
        funciones.aplicar_antibiotico(no_resistentes,bacterias,material_genetico,pl)
        #se regenera la poblacion para llegar a la cantidad de bacterias inicial
        funciones.regeneracion_poblacion(bacterias,sp,size)
        #se busca el mejor y peor fitness
        funciones.mejor_peor_fitness(bacterias,mejor_peor)
        if mejor_peor[0].fitness_real < mejor_fitness:
            mejor_fitness = mejor_peor[0].fitness_real
            mejor_cv = mejor_peor[0].cv
            mejor_cromosoma = mejor_peor[0].cromosoma[:]
        #comienza el proceso de variacion genetica libre hasta que se detenga el estancamiento
        if i % 100 == 0:
            stdscr.addstr(0,0,"Iteracion {0}\tvariabilidad genetica{1}".format(i,var))
            stdscr.addstr(1,0,"Mejor fitness global\t{0}".format(mejor_fitness))
            stdscr.addstr(2,0,"Mejor fitness\t\t{0}".format(mejor_peor[0].fitness_real))
            stdscr.addstr(3,0,"Cantidad de vehiculos \t{0}".format(mejor_peor[0].cv))
            stdscr.addstr(4,0,"Mejor fitness\t\t{0}".format(mejor_peor[1].fitness_real))
            stdscr.addstr(5,0,"Cantidad de vehiculos \t\t{0}".format(mejor_peor[1].cv))
            stdscr.refresh()
        while mejor_peor[0].fitness == mejor_peor[1].fitness:
            var = var + 1
            funciones.conjugacion_libre_bacterias(bacterias,pcl)
            funciones.transformacion_bacterias(bacterias,material_genetico,ptl)
            funciones.mutacion_libre(bacterias,pml)
            funciones.mejor_peor_fitness(bacterias,mejor_peor)
            if mejor_peor[0].fitness_real < mejor_fitness:
                mejor_fitness = mejor_peor[0].fitness_real
                mejor_cv = mejor_peor[0].cv
                mejor_cromosoma = mejor_peor[0].cromosoma[:]
    stdscr.addstr(6,0,"Mejor fitness\t\t{0}".format(mejor_fitness))
    stdscr.addstr(7,0,"Cantidad de vehiculos \t\t{0}".format(mejor_cv))
    stdscr.addstr(8,0,"cromosoma\t\t{0}".format(mejor_cromosoma))
    stdscr.refresh()
    time.sleep(10)
    curses.echo()
    curses.nocbreak()
    stdscr.keypad(False)
    curses.endwin()
